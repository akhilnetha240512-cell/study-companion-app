# Study Companion — Android App (Capacitor)

This folder is a ready-to-go Capacitor project. Your `study-companion.html`
is already inside it as `www/index.html`. I couldn't run `npm install` or
build the Android project on my end (no internet/Android SDK access in
this sandbox), so finish it on your own machine with these steps.

## Requirements (install once)
- [Node.js](https://nodejs.org) (v18+)
- [Android Studio](https://developer.android.com/studio) (includes the
  Android SDK — open it once after install so it finishes setup)
- A Java JDK 17 (Android Studio bundles one; no separate install usually
  needed)

## Steps

1. **Unzip this folder** and open a terminal inside it.

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Add the Android platform:**
   ```
   npx cap add android
   ```
   This generates the full native Android project in an `android/` folder.

4. **Sync your web app into it** (run this again anytime you edit
   `www/index.html`):
   ```
   npx cap sync android
   ```

5. **Open in Android Studio:**
   ```
   npx cap open android
   ```
   Android Studio will open the project. Let it finish Gradle sync
   (first time can take a few minutes).

6. **Test on a device/emulator:** click the green ▶ Run button in
   Android Studio.

7. **Build a release bundle for the Play Store:**
   - In Android Studio: **Build → Generate Signed Bundle / APK**
   - Choose **Android App Bundle (.aab)**
   - Create a new keystore (⚠️ **save this file and its passwords
     somewhere safe and permanent** — you need the *same* keystore for
     every future update, or you'll have to publish as a brand-new app)
   - Build the **release** variant

## Before publishing, edit these

- **App ID** in `capacitor.config.json` — currently
  `com.tsscert.studycompanion`. This is a placeholder; change it to
  something you control (reverse-domain style, e.g.
  `com.yourname.studycompanion`), since it's permanent once published
  and can't be reused by another app later.
- **App icon & splash screen** — Capacitor ships default placeholders.
  Replace them via `android/app/src/main/res/` (Android Studio's Image
  Asset tool: right-click `res` → New → Image Asset).
- **Privacy policy** — Play Store requires a privacy policy URL for
  every app, especially since this one takes photos (quiz feature) and
  stores an API key locally. A simple hosted page describing what data
  is stored and where is enough.
- **The API key field** (Solver/Quiz tab) — since users paste their own
  Anthropic API key into the app, make sure your store listing is clear
  about this, so it doesn't look like hidden data collection.

## Publishing to the Play Store

1. Create a [Google Play Developer account](https://play.google.com/console/signup)
   ($25 one-time fee, tied to your identity).
2. In Play Console: **Create app** → fill in title, description,
   category, screenshots, privacy policy URL.
3. Upload the `.aab` file from step 7 above under **Release → Production**
   (or start with **Internal testing** to try it privately first).
4. Complete the required content rating questionnaire and data safety
   form.
5. Submit for review (usually a few hours to a few days).

## Notes
- If you'd rather not deal with Android Studio, `npx cap sync android`
  + a CI service like [Codemagic](https://codemagic.io) can build the
  `.aab` for you from this same project — useful if you want to avoid
  local setup entirely.
