# Option 1 — TWA (Trusted Web Activity)

This wraps a **live, hosted** version of the app instead of bundling the
files directly. Use this if you'd rather host the site (e.g. GitHub
Pages, Netlify, Vercel) and keep it updatable without republishing the
app every time.

## Steps

1. **Host the file.** Upload `study-companion.html` (renamed to
   `index.html`) to any static host. Free options:
   - [Netlify Drop](https://app.netlify.com/drop) — drag and drop, get
     a URL instantly
   - [GitHub Pages](https://pages.github.com)
   - [Vercel](https://vercel.com)

   You'll get a URL like `https://your-app.netlify.app`.

2. **Install Bubblewrap:**
   ```
   npm install -g @bubblewrap/cli
   ```

3. **Initialize the TWA project**, pointing at your hosted URL:
   ```
   bubblewrap init --manifest https://your-app.netlify.app/manifest.json
   ```
   (Bubblewrap can also generate a manifest for you if you don't have
   one — run `bubblewrap init` without `--manifest` and answer its
   prompts with your URL.)

4. **Build:**
   ```
   bubblewrap build
   ```
   This produces a signed `.aab` ready for Play Store upload.

5. **Verify Digital Asset Links** — TWAs require a
   `.well-known/assetlinks.json` file on your hosting domain, proving
   you own both the app and the site. Bubblewrap generates this file
   for you during `init`; you just need to upload it to
   `https://your-app.netlify.app/.well-known/assetlinks.json`.

## Which option should I actually use?

- **Capacitor (Option 2, in the parent folder)** — simpler, works
  fully offline, no hosting needed. Good default choice.
- **TWA (this option)** — better if you want to update the app's
  content without pushing a new Play Store release each time (since
  it just loads your live URL).

Send me the hosted URL once you have one and I can generate the actual
Bubblewrap manifest/config for you.
